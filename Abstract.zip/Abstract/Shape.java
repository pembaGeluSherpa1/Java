package Abstract;

abstract class Shape {
    abstract void area();
    abstract void corner();
}
